import React, { useState, useMemo } from 'react';
import { 
  BarChart3, 
  RefreshCw, 
  Search, 
  Layers, 
  List, 
  Inbox, 
  Calendar,
  AlertCircle
} from 'lucide-react';

/**
 * Dashboard de Facturación OpenClaw Sync
 * Versión React + Tailwind - Estilo Industrial "Excel-Like"
 */
export default function App() {
  // --- ESTADOS ---
  const [allInvoices, setAllInvoices] = useState([]);
  const [empresa, setEmpresa] = useState('MI_EMPRESA');
  const [filterText, setFilterText] = useState('');
  const [dateStart, setDateStart] = useState('');
  const [dateEnd, setDateEnd] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [status, setStatus] = useState({ type: 'inactive', message: 'Servicio Inactivo' });

  // --- CONEXIÓN CON API ---
  const fetchData = async () => {
    setIsLoading(true);
    setStatus({ type: 'loading', message: 'Sincronizando...' });

    try {
      // Ajusta el puerto si tu API de .NET usa uno distinto al 5000
      const response = await fetch(`http://localhost:5000/api/Facturas/${empresa}/descarga?limite=100`);
      
      if (!response.ok) throw new Error("Error en la respuesta del servidor");
      
      const data = await response.json();
      setAllInvoices(data);
      setStatus({ type: 'success', message: `SDK Conectado (${data.length} Facturas)` });
    } catch (error) {
      console.error(error);
      setStatus({ type: 'error', message: 'Error de enlace con API' });
    } finally {
      setIsLoading(false);
    }
  };

  // --- LÓGICA DE FILTRADO Y AGRUPACIÓN (Imágenes 1 y 2) ---
  const { detailedRows, summaryData, granTotal } = useMemo(() => {
    const rows = [];
    const summaryMap = new Map();
    let total = 0;

    allInvoices.forEach(doc => {
      // Parseo de fecha dd/mm/yyyy para filtros
      const parts = doc.fecha.split('/');
      const invDate = parts.length === 3 ? new Date(`${parts[2]}-${parts[1]}-${parts[0]}`) : new Date(doc.fecha);

      doc.conceptos.forEach((mov, index) => {
        const matchesSearch = 
          mov.codigoProducto.toLowerCase().includes(filterText.toLowerCase()) || 
          doc.folio.includes(filterText) || 
          (doc.rfc && doc.rfc.toLowerCase().includes(filterText.toLowerCase())) ||
          doc.cliente.toLowerCase().includes(filterText.toLowerCase());

        const matchesDate = 
          (!dateStart || invDate >= new Date(dateStart)) && 
          (!dateEnd || invDate <= new Date(dateEnd));

        if (matchesSearch && matchesDate) {
          // Aplanado para Tabla de Detalle (Imagen 1)
          rows.push({
            fecha: doc.fecha,
            factura: doc.folio,
            rfc: doc.rfc || 'N/A',
            codigo: mov.codigoProducto,
            nombre: mov.nombreProducto,
            cantidad: mov.cantidad,
            precio: mov.precioUnitario,
            monto: mov.importe,
            metodoPago: doc.metodoPago || 'PPD',
            uuid: doc.uuid
          });

          // Agrupado para Tabla de Resumen (Imagen 2)
          if (!summaryMap.has(mov.codigoProducto)) {
            summaryMap.set(mov.codigoProducto, {
              codigo: mov.codigoProducto,
              nombre: mov.nombreProducto,
              precio: mov.precioUnitario,
              totalQty: 0,
              totalAmt: 0
            });
          }
          const group = summaryMap.get(mov.codigoProducto);
          group.totalQty += mov.cantidad;
          group.totalAmt += mov.importe;
          total += mov.importe;
        }
      });
    });

    return { 
      detailedRows: rows, 
      summaryData: Array.from(summaryMap.values()),
      granTotal: total
    };
  }, [allInvoices, filterText, dateStart, dateEnd]);

  return (
    <div className="bg-slate-100 text-slate-900 min-h-screen w-full flex flex-col font-sans antialiased">
      
      {/* Header Superior */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-sm w-full">
        <div className="max-w-[1600px] mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-2 rounded-lg shadow-md text-white">
              <BarChart3 className="w-5 h-5" />
            </div>
            <h1 className="text-xl font-black tracking-tighter text-slate-800">
              OPENCLAW <span className="text-blue-600 italic">SYNC</span>
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <div className={`flex items-center gap-2 text-xs font-bold px-4 py-1.5 rounded-full uppercase tracking-widest border
              ${status.type === 'success' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 
                status.type === 'error' ? 'bg-red-50 text-red-600 border-red-100' : 'bg-slate-100 text-slate-500 border-slate-200'}`}>
              <span className={`w-2 h-2 rounded-full ${status.type === 'success' ? 'bg-emerald-500' : status.type === 'error' ? 'bg-red-500' : 'bg-slate-300'}`}></span>
              {status.message}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto w-full px-6 py-8 flex-1">
        
        {/* Panel de Controles */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 mb-8 flex flex-wrap items-end gap-6 text-left">
          <div className="flex-none">
            <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 ml-1 tracking-widest">Directorio Empresa</label>
            <div className="flex gap-2">
              <input 
                type="text" 
                value={empresa}
                onChange={(e) => setEmpresa(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-sm font-bold outline-none w-48 focus:ring-2 focus:ring-blue-500 transition-all" 
              />
              <button 
                onClick={fetchData} 
                disabled={isLoading}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-xl flex items-center gap-2 transition-all text-xs font-bold uppercase tracking-wider disabled:opacity-50 shadow-lg shadow-blue-100"
              >
                <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
                Sincronizar API
              </button>
            </div>
          </div>

          <div className="flex-1 min-w-[300px]">
            <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 ml-1 tracking-widest">Búsqueda Inteligente</label>
            <div className="relative">
              <Search className="absolute left-4 top-3 w-4 h-4 text-slate-400" />
              <input 
                type="text" 
                placeholder="No. Parte / Factura / RFC / Cliente..."
                value={filterText}
                onChange={(e) => setFilterText(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl pl-12 pr-4 py-2 w-full text-sm font-medium outline-none focus:ring-2 focus:ring-blue-500 transition-all" 
              />
            </div>
          </div>

          <div className="flex-none">
            <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 ml-1 tracking-widest">Rango de Fecha</label>
            <div className="flex gap-2">
              <input 
                type="date" 
                value={dateStart}
                onChange={(e) => setDateStart(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold outline-none focus:ring-2 focus:ring-blue-500 transition-all" 
              />
              <input 
                type="date" 
                value={dateEnd}
                onChange={(e) => setDateEnd(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold outline-none focus:ring-2 focus:ring-blue-500 transition-all" 
              />
            </div>
          </div>
        </div>

        {/* --- SECCIÓN 1: RESUMEN (Imagen 2) --- */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-4 ml-1">
            <Layers className="w-5 h-5 text-blue-600" />
            <h2 className="text-sm font-black text-slate-800 uppercase tracking-widest">Resumen por Número de Parte</h2>
          </div>
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-900 text-white text-[10px] font-black uppercase tracking-widest">
                  <th className="py-3 px-6 w-16 text-center border-r border-slate-800 uppercase">NO</th>
                  <th className="py-3 px-6 border-r border-slate-800 uppercase">No. Parte</th>
                  <th className="py-3 px-6 border-r border-slate-800 uppercase">Descripción</th>
                  <th className="py-3 px-6 text-right border-r border-slate-800 uppercase">Precio Prom.</th>
                  <th className="py-3 px-6 text-right border-r border-slate-800 uppercase">TTL Qty</th>
                  <th className="py-3 px-6 text-right uppercase">Total Amt</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs font-semibold text-slate-700">
                {summaryData.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="text-center py-20 text-slate-400 italic flex flex-col items-center gap-2">
                       <Inbox className="w-8 h-8 opacity-20" />
                       No hay datos sincronizados del SDK
                    </td>
                  </tr>
                ) : (
                  summaryData.map((item, i) => (
                    <tr key={item.codigo} className="hover:bg-slate-50 transition-colors group">
                      <td className="py-3 px-6 text-center text-slate-400 font-bold border-r border-slate-50">{i + 1}</td>
                      <td className="py-3 px-6 font-black text-slate-900 border-r border-slate-50 group-hover:text-blue-600">{item.codigo}</td>
                      <td className="py-3 px-6 font-medium text-slate-500 border-r border-slate-50">{item.nombre}</td>
                      <td className="py-3 px-6 text-right text-slate-400 font-mono border-r border-slate-50">
                        $ {item.precio.toLocaleString(undefined, { minimumFractionDigits: 4 })}
                      </td>
                      <td className="py-3 px-6 text-right font-black text-slate-900 border-r border-slate-50">{item.totalQty.toLocaleString()}</td>
                      <td className="py-3 px-6 text-right font-black text-blue-600">
                        $ {item.totalAmt.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
              <tfoot className="bg-slate-50 border-t-2 border-slate-200">
                <tr>
                  <td colSpan="5" className="text-right py-4 px-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">Total General del Periodo</td>
                  <td className="text-right py-4 px-6 text-lg font-black text-slate-900">
                    $ {granTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        {/* --- SECCIÓN 2: DETALLE GLOBAL (Imagen 1) --- */}
        <div>
          <div className="flex items-center gap-3 mb-4 ml-1">
            <List className="w-5 h-5 text-blue-600" />
            <h2 className="text-sm font-black text-slate-800 uppercase tracking-widest">Detalle Individual de Movimientos</h2>
          </div>
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse whitespace-nowrap">
                <thead>
                  <tr className="bg-slate-100 border-b border-slate-200 text-slate-500 text-[10px] font-black uppercase tracking-widest">
                    <th className="py-4 px-6 uppercase">Fecha</th>
                    <th className="py-4 px-6 text-center uppercase">Factura</th>
                    <th className="py-4 px-6 uppercase">RFC Cliente</th>
                    <th className="py-4 px-6 uppercase">No. Parte</th>
                    <th className="py-4 px-6 uppercase">Descripción</th>
                    <th className="py-4 px-6 text-right uppercase">Qty</th>
                    <th className="py-4 px-6 text-right uppercase">Precio</th>
                    <th className="py-4 px-6 text-right uppercase">Monto</th>
                    <th className="py-4 px-6 text-center uppercase">Pago</th>
                    <th className="py-4 px-6 uppercase">UUID Fiscal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 text-[11px] font-medium text-slate-600">
                  {detailedRows.length === 0 ? (
                    <tr>
                      <td colSpan="10" className="text-center py-24 text-slate-400 italic">
                        Los movimientos de facturación aparecerán aquí después de la sincronización
                      </td>
                    </tr>
                  ) : (
                    detailedRows.map((row, idx) => (
                      <tr key={`${row.factura}-${idx}`} className="hover:bg-blue-50/50 group transition-all">
                        <td className="py-2.5 px-6 font-bold text-slate-500">{row.fecha}</td>
                        <td className="py-2.5 px-6 text-center">
                          <span className="px-2.5 py-1 bg-white text-slate-800 rounded-lg font-black border border-slate-200 shadow-sm group-hover:border-blue-300">
                            {row.factura}
                          </span>
                        </td>
                        <td className="py-2.5 px-6 font-mono text-blue-600 font-bold tracking-tighter">{row.rfc}</td>
                        <td className="py-2.5 px-6 font-black text-slate-900 group-hover:text-blue-600">{row.codigo}</td>
                        <td className="py-2.5 px-6 text-slate-500 max-w-[250px] truncate" title={row.nombre}>{row.nombre}</td>
                        <td className="py-2.5 px-6 text-right font-black text-slate-900">{row.cantidad.toLocaleString()}</td>
                        <td className="py-2.5 px-6 text-right text-slate-400 font-mono">$ {row.precio.toFixed(2)}</td>
                        <td className="py-2.5 px-6 text-right font-black text-slate-900">
                          $ {row.monto.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                        <td className="py-2.5 px-6 text-center">
                          <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest bg-slate-50 px-2 py-0.5 rounded border border-slate-100">{row.metodoPago}</span>
                        </td>
                        <td className="py-2.5 px-6 font-mono text-[9px] text-slate-300 group-hover:text-slate-500 uppercase tracking-tighter">
                          {row.uuid || 'N/A'}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}